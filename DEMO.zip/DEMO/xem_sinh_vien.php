<!DOCTYPE html>
<html lang="en">
<head>
    <title>Xem Sinh Viên</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa; /* Màu nền nhẹ nhàng */
        }
        .container {
            margin-top: 50px; /* Khoảng cách từ trên xuống */
            padding: 30px; /* Khoảng cách bên trong */
            background-color: #ffffff; /* Màu nền trắng cho form */
            border-radius: 10px; /* Bo góc */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Đổ bóng */
        }
        h2 {
            text-align: center; /* Canh giữa tiêu đề */
            margin-bottom: 20px; /* Khoảng cách phía dưới tiêu đề */
        }
        .table-hover tbody tr:hover {
            background-color: #f1f1f1; /* Đổi màu nền khi hover trên dòng */
        }
        .btn-primary, .btn-secondary {
            margin-right: 5px;
        }
        .btn-action {
            padding: 8px;
            margin-right: 5px;
        }
        .btn-action i {
            font-size: 16px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Xem Sinh Viên</h2>

    <div class="mb-4">
        <a class="btn btn-primary" href="form_them_sinh_vien.php?maLop=<?php echo htmlspecialchars($_GET['maLop']); ?>">
            <i class="fas fa-plus-circle"></i> Thêm Sinh Viên
        </a>
        <a class="btn btn-secondary" href="lophoc.php?maLop=<?php echo htmlspecialchars($_GET['maLop']); ?>">
            <i class="fas fa-arrow-left"></i> Trở về
        </a>
    </div>
    <a class="btn btn-secondary float-right" href="logout.php">
        <i class="fas fa-sign-out-alt"></i> Đăng xuất
    </a>

    <h3 class="mt-4">Danh Sách Sinh Viên</h3>
    <?php
    include_once("connect.php");
    
    $maLop = htmlspecialchars($_GET['maLop'] ?? '');
    
    // Viết câu truy vấn
    $sql = "SELECT * FROM sinhvien WHERE maLop = '$maLop'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<table class='table table-hover mt-3'>";
        echo "<thead class='thead-dark'><tr><th>Mã sinh viên</th><th>Họ lót</th><th>Tên sinh viên</th><th>Ngày sinh</th><th>Giới tính</th><th>Thao tác</th></tr></thead><tbody>";
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>".$row["maSV"]."</td>";
            echo "<td>".$row["hoLot"]."</td>";
            echo "<td>".$row["tenSV"]."</td>";
            echo "<td>".$row["ngaySinh"]."</td>";
            echo "<td>".$row["gioiTinh"]."</td>";
            echo "<td>";
            ?>
            <!-- Nút sửa sinh viên -->
            <a class="btn btn-warning btn-action" href='sua_sinh_vien.php?maSV=<?php echo $row["maSV"]; ?>&maLop=<?php echo $maLop; ?>'>
                <i class="fas fa-pencil-alt"></i>
            </a>
            <!-- Nút xóa sinh viên -->
            <a class="btn btn-danger btn-action" onclick='return confirm("Bạn có chắc chắn muốn xóa sinh viên này không?")' href='xoa_sinh_vien.php?maSV=<?php echo $row["maSV"]; ?>&maLop=<?php echo $maLop; ?>'>
                <i class="fas fa-trash-alt"></i>
            </a>
            <?php
            echo "</td>";
            echo "</tr>";
        }
        echo "</tbody></table>";
    } else {
        echo "<div class='alert alert-warning'>Không có sinh viên nào trong lớp này.</div>";
    }
    
    $conn->close();
    ?>
</div>

</body>
</html>
