-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 14, 2024 at 09:21 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ql_sinhvien`
--

-- --------------------------------------------------------

--
-- Table structure for table `lophoc`
--

CREATE TABLE `lophoc` (
  `maLop` varchar(12) NOT NULL,
  `tenLop` varchar(100) NOT NULL,
  `ghiChu` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lophoc`
--

INSERT INTO `lophoc` (`maLop`, `tenLop`, `ghiChu`) VALUES
('DA21DDA', 'Điều dưỡng A', ''),
('DA21NN', 'Nông nghiệp a', ''),
('DA21TS', 'Nuôi trồng thủy sản', ''),
('DA21TTB', 'Công Nghệ Thông Tin B', ''),
('DA21TTC', 'Đại học công nghệ thông tin C khóa 21', ''),
('DF23TT', 'Liên thông - Công nghệ thông tin khóa 21', 'Liên thông');

-- --------------------------------------------------------

--
-- Table structure for table `sinhvien`
--

CREATE TABLE `sinhvien` (
  `maSV` varchar(9) NOT NULL COMMENT 'Mã sinh viên',
  `hoLot` varchar(20) NOT NULL COMMENT 'Họ lót',
  `tenSV` varchar(10) NOT NULL COMMENT 'Tên sinh viên',
  `ngaySinh` date NOT NULL COMMENT 'Ngày sinh',
  `gioiTinh` varchar(6) NOT NULL COMMENT 'Giới tính',
  `maLop` varchar(20) NOT NULL COMMENT 'Mã Lớp'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sinhvien`
--

INSERT INTO `sinhvien` (`maSV`, `hoLot`, `tenSV`, `ngaySinh`, `gioiTinh`, `maLop`) VALUES
('001', 'Trọng', 'Nghĩa', '2003-11-30', 'Khác', 'DA21TTB'),
('002', 'Mai', 'Uyên', '2003-11-30', 'Nữ', 'DA21TTB'),
('003', 'Minh', 'Nhựt', '2003-10-03', 'Nam', 'DA21TTB'),
('004', 'Phúc', 'Duy', '2003-10-10', 'Nam', 'DA21TTB'),
('008', 'Nhân', 'Phẩm', '2000-11-30', 'Nam', 'DA21DDA'),
('NN1', 'Mai', 'Khoa', '2003-11-30', 'Nam', 'DA21NN'),
('NN2', 'Lê', 'Minh', '2000-06-02', 'Nam', 'DA21NN'),
('NN3', 'Đỗ', 'Uyên', '2003-06-02', 'Nữ', 'DA21NN'),
('NN4', 'Thành', 'Mai', '2000-04-05', 'Nam', 'DA21NN'),
('NN5', 'Tải', 'Hiếu', '2000-11-29', 'Nam', 'DA21NN'),
('NN7', 'Trương', 'Huy', '1999-05-17', 'Nam', 'DA21NN');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(2, 'user', '$2y$10$gtyzN.9N4cC9YmyH6hhQm.oRN11e3y4hRD0ntAha3E914jd6yNyzO'),
(3, 'admin', '$2y$10$p9dVLmoiqXnr9oTTpWXfn.CUMwUglk0A9N0p6GiPc3aNibaZu37fy'),
(4, 'admin1', '$2y$10$g7c55L5IkLOKipGcBg7fR.D8RtLJUljEqAxPc6MDgfsnxPdIzf9o6'),
(5, 'admin2', '$2y$10$BzVFKV6j7T9x.9A9dbLi6ej/oAUlwYCjKZMa7q1EVErfLmEYjeSwS');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lophoc`
--
ALTER TABLE `lophoc`
  ADD PRIMARY KEY (`maLop`);

--
-- Indexes for table `sinhvien`
--
ALTER TABLE `sinhvien`
  ADD PRIMARY KEY (`maSV`),
  ADD KEY `maLop` (`maLop`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sinhvien`
--
ALTER TABLE `sinhvien`
  ADD CONSTRAINT `sinhvien_ibfk_1` FOREIGN KEY (`maLop`) REFERENCES `lophoc` (`maLop`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
