<?php
include_once("connect.php");

$maSV = htmlspecialchars($_GET['maSV']);

// Truy vấn thông tin sinh viên dựa vào mã sinh viên
$sql = "SELECT * FROM sinhvien WHERE maSV = '$maSV'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Không tìm thấy sinh viên.";
    exit();
}

// Khởi tạo biến lỗi
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $hoLot = $_POST['hoLot'];
    $tenSV = $_POST['tenSV'];
    $ngaySinh = $_POST['ngaySinh'];
    $gioiTinh = $_POST['gioiTinh'];

    // Kiểm tra dữ liệu nhập vào
    if (empty($hoLot) || empty($tenSV) || empty($ngaySinh) || empty($gioiTinh)) {
        $error = "Tất cả các trường đều là bắt buộc.";
    } elseif (!preg_match("/^[a-zA-ZĐàáạảãâầấậẩẫêềếệểễôồốộổỗơờớợởỡưừứựửữ\s]*$/", $hoLot) || 
              !preg_match("/^[a-zA-ZĐàáạảãâầấậẩẫêềếệểễôồốộổỗơờớợởỡưừứựửữ\s]*$/", $tenSV)) {
        $error = "Họ lót và tên sinh viên chỉ có thể chứa chữ cái và khoảng trắng.";
    } else {
        // Cập nhật dữ liệu trong cơ sở dữ liệu
        $stmt = $conn->prepare("UPDATE sinhvien SET hoLot = ?, tenSV = ?, ngaySinh = ?, gioiTinh = ? WHERE maSV = ?");
        $stmt->bind_param("ssssi", $hoLot, $tenSV, $ngaySinh, $gioiTinh, $maSV);

        if ($stmt->execute()) {
            header("Location: xem_sinh_vien.php?maLop=".$_GET['maLop']);
            exit();
        } else {
            $error = "Lỗi: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sửa Sinh Viên</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f0f2f5; /* Nền xám nhạt */
        }
        .container {
            margin-top: 50px;
            max-width: 600px;
            background-color: #ffffff; /* Nền trắng cho form */
            padding: 30px;
            border-radius: 10px; /* Bo góc */
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1); /* Đổ bóng mềm */
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #007bff; /* Màu tiêu đề xanh nổi bật */
        }
        label {
            font-weight: bold;
        }
        .form-control {
            border-radius: 8px;
        }
        button {
            width: 100%; /* Nút bấm rộng 100% */
            border-radius: 8px;
            padding: 10px;
        }
        .form-group {
            margin-bottom: 20px; /* Khoảng cách giữa các nhóm form */
        }
        .error {
            color: red; /* Màu đỏ cho thông báo lỗi */
        }
    </style>
    <script>
        function validateInput() {
            const fields = ["hoLot", "tenSV"];
            fields.forEach(id => { 
                const inputField = document.getElementById(id);
                inputField.addEventListener("input", function() {
                    let x = this.value;
                    let validPattern = /^[a-zA-ZĐàáạảãâầấậẩẫêềếệểễôồốộổỗơờớợởỡưừứựửữ\s]*$/;

                    if (!validPattern.test(x)) {
                        this.value = x.replace(/[^a-zA-ZĐàáạảãâầấậẩẫêềếệểễôồốộổỗơờớợởỡưừứựửữ\s]/g, '');
                        showAlert("Tên và họ lót không được chứa số hoặc ký tự không hợp lệ!",      "danger");
                    }
                });
            });
        }

        function showAlert(message, type) {
            const alertPlaceholder = document.getElementById('alertPlaceholder');
            alertPlaceholder.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert">
                ${message}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>`;
        }

        window.onload = validateInput;
    </script>
</head>
<body>

<div class="container">
    <h2>Sửa Thông Tin Sinh Viên</h2>
    <div id="alertPlaceholder"></div>
    <?php if (!empty($error)): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>
    <form method="post">
        <div class="form-group">
            <label for="hoLot">Họ lót:</label>
            <input type="text" class="form-control" id="hoLot" name="hoLot" value="<?php echo $row['hoLot']; ?>" required>
        </div>
        <div class="form-group">
            <label for="tenSV">Tên sinh viên:</label>
            <input type="text" class="form-control" id="tenSV" name="tenSV" value="<?php echo $row['tenSV']; ?>" required>
        </div>
        <div class="form-group">
            <label for="ngaySinh">Ngày sinh:</label>
            <input type="date" class="form-control" id="ngaySinh" name="ngaySinh" value="<?php echo $row['ngaySinh']; ?>" required>
        </div>
        <div class="form-group">
            <label for="gioiTinh">Giới tính:</label>
            <select class="form-control" id="gioiTinh" name="gioiTinh">
                <option value="Nam" <?php if($row['gioiTinh'] == 'Nam') echo 'selected'; ?>>Nam</option>
                <option value="Nữ" <?php if($row['gioiTinh'] == 'Nữ') echo 'selected'; ?>>Nữ</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Lưu Thay Đổi</button>
    </form>
</div>

</body>
</html>
