<?php
include_once("connect.php");

// Kiểm tra mã lớp
if (isset($_GET['maLop'])) {
    $maLop = $_GET['maLop'];

    // Sử dụng prepared statement để bảo vệ khỏi SQL Injection
    $stmt = $conn->prepare("DELETE FROM lophoc WHERE maLop = ?");
    $stmt->bind_param("s", $maLop); 

    // Thực thi
    if ($stmt->execute() === TRUE) {

        header("Location: lophoc.php");
        exit; 
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Không tìm thấy mã lớp.";
}

// Đóng kết nối
$conn->close();
?>
