<?php
include_once("connect.php");

// Lấy dữ liệu từ form
$ma = $hoLot = $ten = $ngaySinh = $gioiTinh = $maLop = "";
if(!empty($_POST["txtMa"]) && !empty($_POST["hoLot"]) && !empty($_POST["txtTen"]) && !empty($_POST["ngaySinh"]) && !empty($_POST["gioiTinh"])) {
    $ma = $_POST["txtMa"];
    $hoLot = $_POST["hoLot"];
    $ten = $_POST["txtTen"];
    $ngaySinh = $_POST["ngaySinh"];
    $gioiTinh = $_POST["gioiTinh"];
    $maLop = $_POST["maLop"];
}

// Viết câu truy vấn
$sql = "INSERT INTO sinhvien (maSV, hoLot, tenSV, ngaySinh, gioiTinh, maLop) VALUES ('$ma', '$hoLot', '$ten', '$ngaySinh', '$gioiTinh', '$maLop')";

// Thực thi câu truy vấn
if ($conn->query($sql) === TRUE) {
    header("Location: xem_sinh_vien.php?maLop=$maLop"); 
} else {
    echo "Error: " . $conn->error; // Hiển thị lỗi nếu có
}


$conn->close();
?>
