<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <title>Tạo tài khoản</title>
</head>
<body>
    <div class="container mt-5">
        <h2>Tạo tài khoản</h2>
        <form action="taotaikhoan.php" method="post">
            <div class="form-group">
                <label for="username">Tên tài khoản:</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Mật khẩu:</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary">Tạo tài khoản</button>
        </form>
    </div>
</body>
</html>
