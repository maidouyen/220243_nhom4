<!DOCTYPE html>
<html lang="en">
<head>
  <title>SỬA THÔNG TIN LỚP HỌC</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    body {
      background-color: #e9ecef; /* Màu nền xám nhẹ */
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .container {
      margin-top: 50px; /* Khoảng cách từ trên xuống */
      padding: 40px; /* Khoảng cách bên trong */
      background-color: #ffffff; /* Màu nền trắng cho form */
      border-radius: 10px; /* Bo góc */
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.1); /* Đổ bóng nhẹ */
    }
    h2 {
      text-align: center;
      margin-bottom: 30px;
      font-weight: bold;
      color: #343a40; /* Màu tiêu đề */
    }
    .form-group label {
      font-weight: bold;
      color: #495057; /* Màu chữ của nhãn */
    }
    .btn-primary {
      background-color: #007bff;
      border-color: #007bff;
    }
    .btn-primary:hover {
      background-color: #0056b3;
      border-color: #004085;
    }
    .btn-secondary {
      background-color: #6c757d;
      border-color: #6c757d;
    }
    .btn-secondary:hover {
      background-color: #5a6268;
      border-color: #545b62;
    }
    .fa {
      margin-right: 8px;
    }
  </style>
</head>
<body>

<div class="container">
  <h2><i class="fas fa-edit"></i> SỬA THÔNG TIN LỚP HỌC</h2>
  
  <?php
    include_once("connect.php");

    // Kiểm tra mã lớp từ URL
    if (isset($_GET['ma'])) {
        $maLop = $_GET['ma'];

        // Truy vấn để lấy thông tin lớp
        $sql = "SELECT * FROM lophoc WHERE maLop = '$maLop'";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $tenLop = $row['tenLop'];
        } else {
            echo "<div class='alert alert-danger'>Không tìm thấy lớp.</div>";
            exit;
        }
    }

    // Xử lý khi người dùng gửi form
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $maLopMoi = $_POST['txtMa'];
        $tenLop = $_POST['txtTen'];

        // Câu truy vấn cập nhật
        $sqlUpdate = "UPDATE lophoc SET maLop = '$maLopMoi', tenLop = '$tenLop' WHERE maLop = '$maLop'";
        
        if ($conn->query($sqlUpdate) === TRUE) {
            echo "<div class='alert alert-success'>Cập nhật thành công!</div>";
            header("refresh:2; url=lophoc.php"); // Quay lại trang danh sách sau 2 giây
            exit;
        } else {
            echo "<div class='alert alert-danger'>Lỗi: " . $conn->error . "</div>";
        }
    }

    $conn->close();
  ?>

  <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]."?ma=$maLop");?>">
    <div class="form-group">
      <label for="txtMa">Mã lớp:</label>
      <input type="text" class="form-control" id="txtMa" name="txtMa" value="<?php echo $maLop; ?>" required>
    </div>
    <div class="form-group">
      <label for="txtTen">Tên lớp:</label>
      <input type="text" class="form-control" id="txtTen" name="txtTen" value="<?php echo $tenLop; ?>" required>
    </div>
    <button type="submit" class="btn btn-primary btn-block">
      <i class="fas fa-save"></i> Lưu thay đổi
    </button>
    <a href="lophoc.php" class="btn btn-secondary btn-block">
      <i class="fas fa-times"></i> Hủy
    </a>
  </form>
</div>

</body>
</html>
