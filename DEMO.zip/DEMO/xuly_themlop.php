<!DOCTYPE html>
<html lang="en">
<head>
  <title>THÊM LỚP HỌC</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body {
      background-color: #f8f9fa; /* Màu nền nhẹ nhàng */
    }
    .container {
      margin-top: 50px; /* Khoảng cách từ trên xuống */
      padding: 30px; /* Khoảng cách bên trong */
      background-color: #ffffff; /* Màu nền trắng cho form */
      border-radius: 10px; /* Bo góc */
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Đổ bóng */
    }
  </style>
</head>
<body>

<div class="container">
  <h2 class="text-center">THÊM LỚP HỌC</h2>
  
  <?php
    include_once("connect.php");

    // Xử lý khi người dùng gửi form
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $ma = $_POST["txtMa"];
        $ten = $_POST["txtTen"];

        // Viết câu truy vấn
        $sql = "INSERT INTO lophoc (maLop, tenLop) VALUES ('$ma', '$ten')";

        // Thực thi
        if ($conn->query($sql) === TRUE) {
            echo "<div class='alert alert-success'>Thêm lớp thành công!</div>";
            header("refresh:2; url=lophoc.php"); 
            exit;
        } else {
            echo "<div class='alert alert-danger'>Lỗi: " . $conn->error . "</div>";
        }
    }
    
    // Đóng kết nối
    $conn->close();
  ?>

  <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <div class="form-group">
      <label for="txtMa">Mã lớp:</label>
      <input type="text" class="form-control" id="txtMa" name="txtMa" required>
    </div>
    <div class="form-group">
      <label for="txtTen">Tên lớp:</label>
      <input type="text" class="form-control" id="txtTen" name="txtTen" required>
    </div>
    <button type="submit" class="btn btn-primary btn-block">Thêm lớp</button>
    <a href="lophoc.php" class="btn btn-secondary btn-block">Trở về</a>
  </form>
</div>

</body>
</html>
