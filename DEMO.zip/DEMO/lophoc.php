
<?php
session_start();
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>QUẢN LÝ THÔNG TIN LỚP HỌC</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    body {
      background-color: #f8f9fa; 
    }
    .container {
      margin-top: 50px; 
      padding: 30px; 
      background-color: #ffffff; 
      border-radius: 10px; 
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.1); 
    }
    h2 {
      text-align: center; 
      margin-bottom: 30px; 
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: #343a40;
    }
    .btn {
      margin-bottom: 15px; 
      font-size: 16px;
    }
    .table-hover tbody tr:hover {
      background-color: #f1f1f1;
    }
    .btn-sm {
      padding: 8px 12px;
      font-size: 14px;
    }
    .fa {
      margin-right: 6px;
    }
    .alert {
      margin-top: 20px;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>QUẢN LÝ THÔNG TIN LỚP HỌC</h2>
  
  <a class="btn btn-primary" href="form_lop.php">
    <i class="fas fa-plus-circle"></i> Thêm mới
  </a>

  <a class="btn btn-secondary float-right" href="logout.php">
    <i class="fas fa-sign-out-alt"></i> Đăng xuất
  </a>

  <?php
    include_once("connect.php");
    
    $sql = "SELECT * FROM lophoc";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
      echo "<table class='table table-hover mt-3'>";
      echo "<thead class='thead-dark'><tr><th>Mã lớp</th><th>Tên lớp</th><th>Xem sinh viên</th><th>Sửa</th><th>Xóa</th></tr></thead><tbody>";
      while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row["maLop"]."</td>";
        echo "<td>".$row["tenLop"]."</td>";
        echo "<td>";
        ?>
        <a class="btn btn-info btn-sm" href="xem_sinh_vien.php?maLop=<?php echo $row["maLop"]; ?>">
          <i class="fas fa-eye"></i> Xem sinh viên
        </a>
        <?php
        echo "</td>";
        echo "<td>";
        ?>
        <a class="btn btn-warning btn-sm" href="sua_lop.php?ma=<?php echo $row["maLop"];?>">
          <i class="fas fa-edit"></i> Sửa
        </a>
        <?php
        echo "</td>";
        echo "<td>";
        ?>
        
        <a class="btn btn-danger btn-sm" onclick='return confirm("Có thực sự muốn xóa không?")' href='xoa_lop.php?maLop=<?php echo $row["maLop"]; ?>'>
          <i class="fas fa-trash"></i> Xóa
        </a>
        <?php
        echo "</td>";
        echo "</tr>";
      }
      
      echo "</tbody></table>";
    } else {
      echo "<div class='alert alert-warning'>Không có dữ liệu lớp học.</div>";
    }
    $conn->close();
  ?>
</div>

</body>
</html>
