<?php
session_start();
include_once("connect.php"); // Kết nối đến cơ sở dữ liệu

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lấy dữ liệu từ form
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Mã hóa mật khẩu
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Kiểm tra xem tài khoản đã tồn tại chưa
    $check_sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($check_sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "Tài khoản đã tồn tại. Vui lòng chọn tên tài khoản khác.";
    } else {
        // Thêm tài khoản mới vào cơ sở dữ liệu
        $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $username, $hashed_password);

        if ($stmt->execute()) {
            echo "Tạo tài khoản thành công!";
            // Chuyển hướng đến trang đăng nhập
            header("location: login.php");
        } else {
            echo "Có lỗi xảy ra khi tạo tài khoản: " . $conn->error;
        }
    }

    $stmt->close();
    $conn->close();
}
?>
