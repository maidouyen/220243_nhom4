<!DOCTYPE html> 
<html lang="en">
<head>
    <title>Thêm Sinh Viên</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #e9ecef;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container {
            margin-top: 50px;
            max-width: 600px;
            background-color: #ffffff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            font-weight: bold;
            color: #495057;
            margin-bottom: 30px;
        }
        .form-group label {
            font-weight: 600;
            color: #495057;
        }
        .form-control {
            border: 1px solid #ced4da;
            padding: 12px;
            font-size: 16px;
            border-radius: 5px;
            transition: border-color 0.3s ease;
        }
        .form-control:focus {
            border-color: #80bdff;
            box-shadow: 0 0 5px rgba(128, 189, 255, 0.5);
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            padding: 12px 20px;
            font-size: 18px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004085;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
            padding: 12px 20px;
            font-size: 18px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }
        .btn-block {
            margin-top: 20px;
        }
    </style>
    <script>
    function validateInput() {
        const fields = ["hoLot", "txtTen", "txtMa"]; // Thêm "maSV" vào danh sách
        fields.forEach(id => {
            const inputField = document.getElementById(id);
            inputField.addEventListener("input", function() {
                let x = this.value;

                let validPattern;
                if (id === "txtMa") {
                    // Chỉ cho phép nhập số cho mã sinh viên
                    validPattern = /^[0-9]*$/;
                } else {
                    // Cho phép nhập chữ và khoảng trắng cho họ và tên
                    validPattern = /^[a-zA-ZĐàáạảãâầấậẩẫêềếệểễôồốộổỗơờớợởỡưừứựửữ\s]*$/;
                }

                if (!validPattern.test(x)) {
                    // Thay thế giá trị không hợp lệ
                    if (id === "txtMa") {
                        this.value = x.replace(/[^0-9]/g, '');
                        showAlert("Mã sinh viên chỉ được nhập số!", "danger");
                    } else {
                        this.value = x.replace(/[^a-zA-ZĐàáạảãâầấậẩẫêềếệểễôồốộổỗơờớợởỡưừứựửữ\s]/g, '');
                        showAlert("Tên và họ lót không được chứa số hoặc ký tự không hợp lệ!", "danger");
                    }
                }
            });
        });
    }

    function showAlert(message, type) {
        const alertPlaceholder = document.getElementById('alertPlaceholder');
        alertPlaceholder.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>`;
    }

    window.onload = validateInput;
</script>
</head>
<body>

<div class="container">
    <h2>Thêm Sinh Viên</h2>
    <div id="alertPlaceholder"></div> <!-- Nơi hiển thị thông báo lỗi -->
    <form action="xuly_them_sinh_vien.php" method="post">
        <div class="form-group">
            <label for="txtMa">Mã sinh viên:</label>
            <input type="text" class="form-control" id="txtMa" name="txtMa" placeholder="Nhập mã sinh viên" required>
        </div>
        <div class="form-group">
            <label for="hoLot">Họ lót:</label>
            <input type="text" class="form-control" id="hoLot" name="hoLot" placeholder="Nhập họ lót" required>
        </div>
        <div class="form-group">
            <label for="txtTen">Tên sinh viên:</label>
            <input type="text" class="form-control" id="txtTen" name="txtTen" placeholder="Nhập tên sinh viên" required>
        </div>
        <div class="form-group">
            <label for="ngaySinh">Ngày sinh:</label>
            <input type="date" class="form-control" id="ngaySinh" name="ngaySinh" required>
        </div>
        <div class="form-group">
            <label for="gioiTinh">Giới tính:</label>
            <select class="form-control" id="gioiTinh" name="gioiTinh" required>
                <option value="Nam">Nam</option>
                <option value="Nữ">Nữ</option>
                <option value="Khác">Khác</option>
            </select>
        </div>
        <div class="form-group">
            <label for="maLop">Mã lớp:</label>
            <input type="text" class="form-control" id="maLop" name="maLop" value="<?php echo isset($_GET['maLop']) ? htmlspecialchars($_GET['maLop']) : ''; ?>" readonly>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Thêm</button>
        <a class="btn btn-secondary btn-block" href="xem_sinh_vien.php?maLop=<?php echo htmlspecialchars($_GET['maLop']); ?>">Trở về</a>
    </form>
</div>

</body>
</html>
