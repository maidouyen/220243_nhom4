<?php
	//Kết nối cơ sở dữ liệu trang 277
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "ql_sinhvien";
    //tạo kết nối
	$conn = new mysqli($servername, $username, $password, $dbname);
	//kiểm tra kết nối
	if ($conn->connect_error) {
  		die("Connection failed: " . $conn->connect_error);
	}
?>