<?php
include_once("connect.php");

// Lấy mã sinh viên và mã lớp từ GET
$maSV = $_GET['maSV'] ?? '';
$maLop = $_GET['maLop'] ?? '';

// Kiểm tra nếu có mã sinh viên
if (!empty($maSV)) {
    // Viết câu truy vấn xóa
    $sql = "DELETE FROM sinhvien WHERE maSV = '$maSV'";

    // Thực thi câu truy vấn
    if ($conn->query($sql) === TRUE) {
        header("Location: xem_sinh_vien.php?maLop=$maLop"); 
    } else {
        echo "Error: " . $conn->error; 
    }
}
$conn->close();
?>
