<?php
session_start();
$_SESSION = array(); // Xóa tất cả biến session
session_destroy();   // Hủy session hiện tại
header("location: login.php"); // Chuyển hướng về trang đăng nhập
exit;
?>
