<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <title>Đăng nhập</title>
    <style>
        body {
            background-color: #f7f9fc; /* Màu nền nhẹ nhàng */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-container {
            background-color: #ffffff; /* Màu nền trắng cho form */
            padding: 40px; /* Tăng khoảng cách bên trong */
            border-radius: 10px; /* Bo góc form */
            box-shadow: 0 0 25px rgba(0, 0, 0, 0.2); /* Đổ bóng mạnh hơn */
            width: 100%;
            max-width: 400px;
            transition: transform 0.2s; /* Hiệu ứng khi di chuột */
        }
        .login-container:hover {
            transform: scale(1.02); /* Phóng to nhẹ khi di chuột */
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #343a40; /* Màu chữ */
        }
        .form-group label {
            font-weight: bold; /* Chữ đậm cho nhãn */
        }
        .btn-primary {
            margin-bottom: 10px; /* Khoảng cách giữa các nút */
        }
        .btn-secondary {
            width: 100%; /* Đặt nút Đăng ký chiếm toàn bộ chiều rộng */
            text-align: center; /* Căn giữa chữ trong nút */
        }
        .footer-text {
            text-align: center; /* Căn giữa chữ chân trang */
            margin-top: 20px;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Đăng nhập</h2>
        <form action="xuly_dangnhap.php" method="post">
            <div class="form-group">
                <label for="username">Tên tài khoản:</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Mật khẩu:</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Đăng nhập</button>
            <a href="dangky.php" class="btn btn-secondary">Đăng ký</a>
        </form>
        <div class="footer-text">
            <p>Bạn chưa có tài khoản? <a href="dangky.php">Đăng ký ngay</a></p>
        </div>
    </div>
</body>
</html>
